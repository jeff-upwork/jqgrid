﻿using System.Web.UI;

namespace DemoTree.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}